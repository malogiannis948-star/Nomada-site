const menu = document.querySelector('.menu');
const links = document.querySelector('.nav-links');
menu?.addEventListener('click', () => {
  const open = links.classList.toggle('open');
  menu.setAttribute('aria-expanded', open ? 'true' : 'false');
});

document.querySelectorAll('.sizes button').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.sizes button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });
});

document.getElementById('orderBtn')?.addEventListener('click', () => {
  window.open('https://instagram.com/', '_blank', 'noopener');
});
